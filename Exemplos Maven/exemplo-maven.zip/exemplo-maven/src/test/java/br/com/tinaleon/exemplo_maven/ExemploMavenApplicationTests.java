package br.com.tinaleon.exemplo_maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
